declare class ExtractUnit extends eui.Skin{
}
declare class GameStatisticsUI extends eui.Skin{
}
declare class GameUI extends eui.Skin{
}
declare class GameApprove extends eui.Skin{
}
declare class GameAlertUI extends eui.Skin{
}
declare class GameHelpUi extends eui.Skin{
}
declare class LanguageUI extends eui.Skin{
}
declare class NewFile extends eui.Skin{
}
